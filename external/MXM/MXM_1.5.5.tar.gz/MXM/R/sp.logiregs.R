sp.logiregs <- function(target, dataset, logged = FALSE) {
  Rfast2::sp.logiregs(target, dataset, logged = logged)
}


